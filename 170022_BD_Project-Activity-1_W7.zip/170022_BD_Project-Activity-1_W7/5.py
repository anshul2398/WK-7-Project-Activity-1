import pandas as pd
data = pd.read_csv("BreadBasket_DMS.csv") 





data['Date'] = pd.to_datetime(data['Date'],format='%d-%m-%Y')
data['month'] = data['Date'].dt.month


weekday= data.set_index(['month'])

weekday.reset_index(inplace = True)

popular=weekday['month'].value_counts()

print('Number of items sold per month') 
print(popular.head(12).sort_index())

