import pandas as pd


data = pd.read_csv("BreadBasket_DMS.csv") 
data= data.set_index(['Item'])
data= data.drop(['NONE'])
data.reset_index(inplace = True)

#finding out the Frequency
#first we will locate all the transactions done with coffee.
comb= data.loc[data['Item'] == 'Coffee', ['Transaction']]

#we will replace the new transaction ids with old ones and change the items accoringly
new= data['Transaction'].isin(comb['Transaction'])
data['Item']=data[new]

# we will also remove all the NaN values that has emerged due to lack of transaction Id.
newData= data.dropna()

# we will also remove Item Coffee to have a precise data set of items brought togethor with Coffee.
newData= newData.set_index(['Item'])
newData= newData.drop(['Coffee'])
newData.reset_index(inplace = True)
print("\n Filtered Data set :\n")
print(newData)

popular=newData['Item'].value_counts()
Frequency= popular/len(newData)


print('The best item combinations with coffee')
print(popular.head(1))








