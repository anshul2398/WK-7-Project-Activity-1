import pandas as pd
data = pd.read_csv("BreadBasket_DMS.csv") 





data['Date'] = pd.to_datetime(data['Date'],format='%d-%m-%Y')
data['year'] = data['Date'].dt.year


weekday= data.set_index(['year'])
final=weekday.loc[2017]

final['weekday'] = final['Date'].dt.dayofweek
final.reset_index(inplace = True)

coffe= final.set_index(['Item'])
coffe1=coffe.loc['Coffee']
coffe1.reset_index(inplace = True)

popular=coffe1['Date'].value_counts()

print('the five most Coffee Sales day in 2017')
print(popular.head())
