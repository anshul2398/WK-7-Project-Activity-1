#%%

import pandas as pd
data = pd.read_csv("BreadBasket_DMS.csv") 




Top=data['Item'].value_counts()
print('Top 10 Selling Items: ')
print(Top.head(10))



# %%
