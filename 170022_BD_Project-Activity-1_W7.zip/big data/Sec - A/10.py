#%%
import pandas as pd
import matplotlib.pyplot as plt
data = pd.read_csv("BreadBasket_DMS.csv") 


data= data.set_index(['Item'])
data= data.drop(['NONE'])
data.reset_index(inplace = True)

bread= data['Item']== 'Bread'

breaddata= data[bread]


breaddata['Date'] = pd.to_datetime(breaddata['Date'],format='%d-%m-%Y', errors='coerce')
breaddata['weekday'] = breaddata['Date'].dt.weekday
sales=breaddata['weekday'].value_counts()




plt.plot(['week 1', 'week 2', 'week 3', 'week 4', 'week 5', 'week 6', 'week 7'],sales.sort_index(axis = 0))
plt.show()


# %%
