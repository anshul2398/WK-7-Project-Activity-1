import pandas as pd
data = pd.read_csv("BreadBasket_DMS.csv") 


data['Date'] = pd.to_datetime(data['Date'],format='%d-%m-%Y')
data['year'] = data['Date'].dt.year
weekday= data.set_index(['year'])
final=weekday.loc[2016]
final.reset_index(inplace = True)
popular=final['Item'].value_counts()

print('Five most popular bakery items in 2016.')  
print(popular.head())