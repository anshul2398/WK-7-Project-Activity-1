import pandas as pd
data = pd.read_csv("BreadBasket_DMS.csv") 





data['Date'] = pd.to_datetime(data['Date'],format='%d-%m-%Y')
data['weekday'] = data['Date'].dt.dayofweek


weekday= data.set_index(['weekday'])
final=weekday.loc[0]
final.reset_index(inplace = True)

popular=final['Item'].value_counts()
print('Five most popular items sold on Monday') 
print(popular.head())

