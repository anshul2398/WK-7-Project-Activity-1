import pandas as pd
data = pd.read_csv("BreadBasket_DMS.csv") 





data['Date'] = pd.to_datetime(data['Date'],format='%d-%m-%Y')
data['weekday'] = data['Date'].dt.dayofweek


weekday= data.set_index(['weekday'])

weekday.reset_index(inplace = True)

popular=weekday['weekday'].value_counts()

print('Number of items sold per weekday')
print(popular.head(7).sort_index())

