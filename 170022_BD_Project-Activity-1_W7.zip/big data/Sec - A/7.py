import pandas as pd
data = pd.read_csv("BreadBasket_DMS.csv") 






data['Time'] = pd.to_datetime(data['Time'],format= '%H:%M:%S', errors='coerce')
data['hour'] = data['Time'].dt.hour

hour= data.set_index(['hour'])

hour.reset_index(inplace = True)

popular=hour['hour'].value_counts()
print('Number of transactions per hour')
print(popular.head(24).sort_index())

